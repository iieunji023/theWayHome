package com.btc.thewayhome.admin.member;

import lombok.Data;

// 보호소 고유번호와 보호소 명을 객체에 담기 의한 클래스
@Data
public class ShelterNumDto {

    private String s_no;
    private String s_name;

}
