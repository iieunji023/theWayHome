$(document).ready(function () {
    $('#openModalBtn').click(function () {
        $('#myModal').modal('show');
    });
    $('#closeModalBtn').click(function () {
    $('#myModal').modal('hide');
    });
});