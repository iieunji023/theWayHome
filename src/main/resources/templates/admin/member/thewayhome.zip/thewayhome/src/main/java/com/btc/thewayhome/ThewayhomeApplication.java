package com.btc.thewayhome;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThewayhomeApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThewayhomeApplication.class, args);
	}

}
