package com.btc.thewayhome.admin.board.free;

import lombok.Data;

@Data
public class FreeBoardAdminDto {



}
