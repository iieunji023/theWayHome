package com.btc.thewayhome.admin.pets.admin;

import lombok.Data;

@Data
public class AdminShelterListInfoDto {

    private String s_no;
    private String s_name;
    private String s_phone;
    private String s_address;
    private String s_reg_date;
    private String a_m_approval;
    private String a_m_reg_date;

}
