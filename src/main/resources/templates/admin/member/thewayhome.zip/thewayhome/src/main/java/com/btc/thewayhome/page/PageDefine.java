package com.btc.thewayhome.page;

public class PageDefine {

    final static public String DEFAULT_PAGE_NUMBER = "1";
    final static public String DEFAULT_AMOUNT = "6";    

}
