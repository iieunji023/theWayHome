package com.btc.thewayhome;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThewayhomeApplicationTests {

	@Test
	void contextLoads() {
	}

}
