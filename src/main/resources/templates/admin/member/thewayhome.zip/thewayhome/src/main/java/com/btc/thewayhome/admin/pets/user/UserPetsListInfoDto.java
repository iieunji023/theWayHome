package com.btc.thewayhome.admin.pets.user;

import lombok.Data;

@Data
public class UserPetsListInfoDto {

    private String an_no;
    private String an_an_kind;
    private String an_k_kind;
    private int an_n_no;
    private String an_n_start;
    private String an_n_end;
    private String an_p_s_state;
    private String s_no;
    private String s_name;
    private String an_thumbnail;

}
