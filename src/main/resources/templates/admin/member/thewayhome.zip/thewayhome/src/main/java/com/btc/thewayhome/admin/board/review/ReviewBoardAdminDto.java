package com.btc.thewayhome.admin.board.review;

public class ReviewBoardAdminDto {
}
