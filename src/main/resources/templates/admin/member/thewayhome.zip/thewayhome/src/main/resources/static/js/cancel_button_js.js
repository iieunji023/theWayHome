function cancelButton() {
    console.log('boardReplyCancel() CALLED!!');
    history.back();

}