package com.btc.thewayhome.admin.pets.admin;

import lombok.Data;

@Data
public class PetsAdminDto {

    private String an_no;
    private String an_thumbnail;
    private String an_happen_date;
    private String an_happen_place;
    private String an_an_kind;
    private String an_k_kind;
    private String an_color;
    private String an_age;
    private String an_weight;
    private String an_n_no;
    private String an_n_start;
    private String an_n_end;
    private String an_image;
    private String an_p_s_state;
    private String an_g_gender;
    private String an_ne_neuter;
    private String an_special_mark;
    private String s_name;
    private String s_phone;
    private String s_address;
    private String an_o_organization;
    private String an_o_charge;
    private String an_o_charge_tel;
    private String s_no;
}
