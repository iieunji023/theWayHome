package com.btc.thewayhome.user.board.comment;

import lombok.Data;

@Data
public class CommentDto {

    private int b_c_no;
    private String b_type;
    private int b_no;
    private String u_m_id;
    private String b_c_content;
    private String b_c_reg_date;

}
